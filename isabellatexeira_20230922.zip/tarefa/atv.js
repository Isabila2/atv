var http = require('http');
var hm = require('./home');
var cdp = require('./cadastrop');
var cdm = require('./cadastrom');
var cs = require('./consultas');
var sn = require('./sobrenos');
var cr = require('./cirurgia');
var lg = require('./login');
var ex = require('./exames');


http.createServer(function (req,res) {
res.writeHead(200, {'Content-Type':'text/html'});
res.write("<h2>" + "Pagina Home: " + hm.myDateTime() + "<br>");
res.write("Cadastro Paciente: " + cdp.myDateTime() + "<br>");
res.write("Cadastro Medico: " + cdm.myDateTime() + "<br>");
res.write("Pagina Consultas: " + cs.myDateTime() + "<br>");
res.write("Pagina Sobre Nos: " + sn.myDateTime() + "<br>");
res.write("Pagina Cirurgia: " + cr.myDateTime() + "<br>");
res.write("Pagina Login: " + lg.myDateTime() + "<br>");
res.write("Pagina Exames: " + ex.myDateTime() + "<br>");



res.end();
}).listen(5006);

console.log("Servidor iniciado na porta 5006 \(._.)/");
