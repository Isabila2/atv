var http = require('http');
var home = require('./homepage');
var login = require('./loginpage');
var consultas = require('./consultaspage');
var cadastro = require('./cadastropage');

http.createServer( function (req,res) {
res.writeHead(200, {'Content-Type': 'text/html'});
res.write("Tela home:"+home.TelaHome());
res.write("<br>Tela login:"+login.TelaLogin());
res.write("<br>Tela consultas:"+consultas.TelaConsultas());
res.write("<br>Tela cadastro:"+cadastro.TelaCadastro());
res.end();
}).listen(7003);
