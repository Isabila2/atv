exports.TelaConsultas = function () {
return Date();

}
