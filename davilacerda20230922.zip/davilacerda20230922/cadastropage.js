exports.TelaCadastro = function () {
return Date();

}
