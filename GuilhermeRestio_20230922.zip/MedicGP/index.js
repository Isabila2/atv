var http = require('http');
var hm = require('./home');
var cdp = require('./cadastrop');
var cdm = require('./cadastron');
var cs = require('./consultas');
var sn = require('./sobrenos');
var cr = require('./cirurgia');

http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type': 'text/html' });

    res.write("Página Home: " + hm.myDateTime() + "<br>");
    res.write("Cadastro Paciente: " + cdp.myDateTime() + "<br>");
    res.write("Cadastro Médico: " + cdm.myDateTime() + "<br>");
    res.write("Página Consultas: " + cs.myDateTime() + "<br>");
    res.write("Cadastro Sobre Nós: " + sn.myDateTime() + "<br>");
    res.write("Cadastro Cirurgia: " + cr.myDateTime() + "<br>");

    res.end();
}).listen(8080);
