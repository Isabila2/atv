exports.myDateTime = function(){
  return new Date().toString();
}
