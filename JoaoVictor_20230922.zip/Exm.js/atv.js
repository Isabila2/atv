var http = require('http');
var hm = require('./home')
var cdp = require('./cadastrop')
var hm = require('./cadastrom')
var hm = require('./consultas')
var hm = require('./sobrenos')
var hm = require('./cirurgia')

http.createServer(function (req,res) {
res.writeHead(200, {'content-type':'text/html'});
res.write("Pagina home: " +hm.myDateTime() + "<br>");
res.write("cadastro paciente: " +hm.myDateTime() + "<br>");
res.write("cadastro medico : " +hm.myDateTime() + "<br>");
res.write("Pagina consultas: " +hm.myDateTime() + "<br>");
res.write("Cadastro sobre nós: " +hm.myDateTime() + "<br>");
res.write("Pagina Cirurgia: " +hm.myDateTime() + "<br>");

res.end();
}).listen(8016)

console.log("Foi que foi!")
